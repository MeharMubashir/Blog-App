import 'package:blogapp/screens/forgot_password.dart';
import 'package:blogapp/screens/home_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';

import '../components/round_button.dart';
import 'login_with_phone_number.dart';
class LogInScreen extends StatefulWidget {
  const LogInScreen({super.key});

  @override
  State<LogInScreen> createState() => _LogInScreenState();
}

class _LogInScreenState extends State<LogInScreen> {
  FirebaseAuth _auth = FirebaseAuth.instance;
  bool showSpinner = false;
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  String email = '',password ='';
  @override
  Widget build(BuildContext context) {
    return ModalProgressHUD(
      inAsyncCall:showSpinner,
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          backgroundColor: Colors.deepOrange,
          title: Text('LogIn',style: TextStyle(color: Colors.white),),
        ),
        body:Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text('LogIn',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 30),),
              Form(
                  key: _formKey,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 30),
                    child: Column(
                      children: [
                        TextFormField(
                          controller:emailController,
                          keyboardType: TextInputType.emailAddress,
                          decoration:const InputDecoration(
                            focusColor: Colors.deepOrange,
                            hintText: 'Email',
                            labelText: 'Email',
                            prefixIcon: Icon(Icons.email),
                            border: OutlineInputBorder(),
                          ),
                          onChanged: (String value){
                            email= value;
                          },
                          validator: (value){
                            return value!.isEmpty ? 'Enter Email' : null ;
                          },
                        ),
                        const SizedBox(height: 5,),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 15),
                          child: TextFormField(
                            controller:passwordController,
                            keyboardType: TextInputType.emailAddress,
                            obscureText: true,
                            decoration: InputDecoration(
                              focusColor: Colors.deepOrange,
                              hintText: 'Password',
                              labelText: 'Password',
                              prefixIcon: Icon(Icons.lock),
                              border: OutlineInputBorder(),
                            ),
                            onChanged: (String value){
                              password= value;
                            },
                            validator: (value){
                              return value!.isEmpty ? 'Enter Password' : null ;
                            },
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 10,bottom: 20 ),
                          child: InkWell(
                            onTap: (){
                              Navigator.push(context, MaterialPageRoute(builder: (context)=>ForgotPasswordScreen()));
                            },
                            child: const Align(
                                alignment: Alignment.centerRight,
                                child: Text('Forgot Password?')),
                          ),
                        ),
                        RoundButton(title: 'LogIn', onPress: ()async{
                          if(_formKey.currentState!.validate()){
                            setState(() {
                              showSpinner =true;
                            });
                            try{
                              final user = await _auth.signInWithEmailAndPassword(email: email.toString().trim(),
                                  password: password.toString().trim());

                              if(user != null){
                                print('Success');
                                toastMessage('User Successfully LogIn');
                                setState(() {
                                  showSpinner =false;
                                });
                                Navigator.push(context, MaterialPageRoute(builder: (context)=>HomeScreen()));
                              }
                            }catch(e){
                              print(e.toString());
                              toastMessage(e.toString());
                              setState(() {
                                showSpinner =false;
                              });
                            }
                          }
                        }),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 20),
                          child: InkWell(
                            onTap: (){
                              Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginWithPhoneNo()));
                            },
                            child: Container(
                              height: 50,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(50),
                                  border: Border.all(
                                      color: Colors.black
                                  )

                              ),
                              child: Center(
                                child: Text('Login with Phone'),
                              ),),
                          ),
                        ),
                      ],
                    ),
                  ))
            ],
          ),
        ),
      ),
    );
  }
  void toastMessage(String message){
    Fluttertoast.showToast(
        msg: message.toString(),
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.SNACKBAR,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.white,
        textColor: Colors.black87,
        fontSize: 16.0
    );
  }
}
